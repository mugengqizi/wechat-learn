Page({
  goLogin(){
    wx.navigateTo({
      url: '../login/login',
    })
  }
})
// pages/zhuce/zhuce.js
Page({
  goNext(){
    wx.navigateTo({
      url: '../zcnext/zcnext',
    })
  }
})
// pages/my/my.js
Page({
  goLogin(){
   wx.navigateTo({
     url: '/pages/dengzhu/dengzhu',
   })
 }
})
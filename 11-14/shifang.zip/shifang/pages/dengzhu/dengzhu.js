
Page({
  goZhuCe(){
    wx.navigateTo({
      url: '/pages/zhuce/zhuce',
    })
  }
})
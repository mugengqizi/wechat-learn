
Page({
  // 定义一个功能，function，函数
  abc(){
    //写很多逻辑代码
    console.log("hello js!");
    console.log("qqqq");
  },
  f2(){
    console.log("i am f2");
    console.log(100);
  }
})